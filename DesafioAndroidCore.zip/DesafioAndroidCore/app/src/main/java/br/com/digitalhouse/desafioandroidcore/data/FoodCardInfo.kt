package br.com.digitalhouse.desafioandroidcore.data

data class FoodCardInfo (val name: String, val address: String, val closesat: String) {
}