package br.com.digitalhouse.desafioandroidcore.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.digitalhouse.desafioandroidcore.R
import br.com.digitalhouse.desafioandroidcore.data.FoodCardInfo

class FoodCardAdapter (private val cardapio: ArrayList<FoodCardInfo>) : RecyclerView.Adapter<FoodCardAdapter.ViewHolder>() {


    class ViewHolder {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(R.id.rc_view)

        return view
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount() = cardapio.size
}